const todaySpan = document.querySelector("#today");
const numbersDiv = document.querySelector(".numbers");
const drawBtn = document.querySelector("#draw");
const resetBtn = document.querySelector("#reset");

let lottoNumbers = [];

const today = new Date();
const todayYear = today.getFullYear();
const todayMonth = today.getMonth() + 1;
const todayDate = today.getDate();
todaySpan.textContent = `${todayYear}년 ${todayMonth}월 ${todayDate}일`

// 랜덤번호를 화면에 추가하는 함수
function paintNumber(number){
    const eachNumDiv = document.createElement("div");
    eachNumDiv.classList.add("eachnum");
    eachNumDiv.textContent = number;
    numbersDiv.append(eachNumDiv);
}

// 버튼 클릭 시, 랜덤 추천 번호 생성
drawBtn.addEventListener("click", function(){
    while(lottoNumbers.length < 6){
        let rn = Math.floor(Math.random() * 45) + 1;
        if(lottoNumbers.indexOf(rn) === -1){
            lottoNumbers.push(rn);
            paintNumber(rn);
        }
    }
    console.log(lottoNumbers);
});

// 버튼 클릭 시, 생성된 추첨 번호 삭제
resetBtn.addEventListener("click", function(){
    lottoNumbers.splice(0, 6);
    console.log(lottoNumbers);
    numbersDiv.innerHTML = "";
})