CREATE DATABASE oz_assignment;
USE oz_assignment;

CREATE TABLE oz_fe(
	user_id INT PRIMARY KEY,
    user_name VARCHAR(6) NOT NULL,
    age INT CHECK(age >= 19),
    birth_day DATE,
    phone_num VARCHAR(15) UNIQUE
);

SELECT * FROM oz_fe;

INSERT INTO oz_fe(user_id, user_name, age, birth_day, phone_num)
VALUES (1, '이세종', 38, '1986-09-15', '010-1234-5678'),
	   (2, '김순신', 25, '1999-01-02', '010-7777-8888'),
       (3, '박광개', 42, '1982-07-29', '010-3333-9999');
       
SELECT * FROM oz_fe;

INSERT INTO oz_fe(user_id, user_name, age, birth_day, phone_num)
VALUES (4, '최토대', 18, '2006-12-25', '010-2222-7777'); -- age가 19세 미만이므로 오류 발생!

