-- 데이터 업데이트(UPDATE SET)
-- UPDATE 테이블명
-- SET 컬럼1 = 값1, 컬럼2 = 값2, ...
-- WHERE 조건;

SELECT * FROM users;

-- UPDATE 기본 쿼리
UPDATE users
SET user_name = 'INSEOP'
WHERE user_id = 1;

-- 여러 레코드 동시에 업데이트
SET SQL_SAFE_UPDATES = 0; -- SAFE MODE CONTROL

UPDATE users
SET user_name = 'seniors'
WHERE age >= 60;

-- 업데이트된 레코드 수 확인
SELECT ROW_COUNT();

-- CASE 문은 사용한 업데이트
UPDATE users
SET user_name = CASE
	WHEN age >= 60 THEN 'senior'
    ELSE 'young'
END;

-- LIMIT을 사용한 일부 레코드만 업데이트
UPDATE users
SET user_name = 'top5_young_people'
WHERE age >= 20
LIMIT 2;

-- REGEXP를 사용한 업데이트
UPDATE users
SET email = CONCAT(email, '_new')
WHERE email REGEXP '@example\.com$';