-- 데이터 조회(SELECT FROM)

-- 모든 컬럼 조회
SELECT * FROM users;

-- 특정 컬럼만 조회
SELECT user_name, age FROM users;

-- 중복 데이터 삭제(DISTINCT)
SELECT DISTINCT user_name FROM users;

-- 일시적으로 추가 컬럼 만들기(AS)
SELECT age, age * 100 FROM users; -- 나이와 나이에 100을 곱합 값을 조회
SELECT age, age * 100 AS age100 FROM users; -- AS를 사용하여 새로운 컬럼명 정의

-- 데이터 정렬하기
SELECT * FROM users ORDER BY age; -- 나이순으로 오름차순 정렬
SELECT * FROM users ORDER BY age DESC; -- 나이순으로 내림차순 정렬
SELECT * FROM users ORDER BY age ASC, created DESC;

-- 조건문(WHERE)⭐️⭐️⭐️⭐️⭐️
SELECT * FROM users WHERE age = 30;
SELECT * FROM users WHERE age = 30 AND user_name = 'john';
SELECT * FROM users WHERE age = 33 OR user_name = 'inseop';

SELECT * FROM users WHERE NOT age = 33; -- NOT을 사용한 부정 조건

SELECT * FROM users WHERE age BETWEEN 20 AND 25; -- BETWEEN을 사용한 범위 지정

-- 특정 개수 제한(LIMIT)
SELECT * FROM users LIMIT 5;
SELECT * FROM users LIMIT 3, 3; -- 10번째부터 5개의 데이터 조회(페이징)

-- 결과 그룹핑(GROUP BY)
SELECT age, COUNT(*) AS user_count FROM users GROUP BY age;

-- 특정 조건에 따라 값 반환(CASE WHEN)⭐️⭐️⭐️⭐️⭐️
SELECT user_name, age,
CASE WHEN age >= 20 THEN '성인' 
ELSE '미성년자' END
AS age_group
FROM users;

-- 결과 내림차순으로 순위 부여(ROW_NUMBER())
SELECT 
	user_name, 
    age, 
    ROW_NUMBER() OVER (ORDER BY age DESC) AS 'rank'
FROM users;