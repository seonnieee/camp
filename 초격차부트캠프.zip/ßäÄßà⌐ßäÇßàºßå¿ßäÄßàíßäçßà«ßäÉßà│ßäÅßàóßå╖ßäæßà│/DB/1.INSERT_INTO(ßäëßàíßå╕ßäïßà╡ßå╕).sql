-- 데이터 삽입 쿼리(INSERT INTO)

USE testdatabase;

CREATE TABLE users(
	user_id INT PRIMARY KEY AUTO_INCREMENT,
    user_name TEXT NOT NULL,
    email TEXT NOT NULL,
    age INT
);

SELECT * FROM users;

-- 데이터 삽입 1
INSERT INTO users(user_name, email, age) 
VALUES ('inseop', 'inseop@gmail.com', 25);

-- 데이터 삽입 2
INSERT INTO users(user_name, email)
VALUES ('inseop2', 'inseop2@gamil.com');

-- 데이터 삽입 3
INSERT INTO users(user_name, email, age)
VALUES ('alice', 'alice@example.com', 30),
	   ('bob', 'bob@example.com', 28),
       ('charlie', 'charlie@example.com', 35);
       
-- 중복되는 레코드 피하기
INSERT INTO users(user_name, email)
VALUES ('john_doe', 'john@example.com');

INSERT IGNORE INTO users(user_name, email, age)
VALUES ('john_doe', 'john@example.com', 25);

-- 중복된 레코드 업데이트 : 중복된 값이 있는 경우 해당 레코드를 업데이트함
INSERT IGNORE INTO users(user_name, email, age)
VALUES ('john_doe', 'john@example.com', 100)
ON DUPLICATE KEY UPDATE age = 25;

-- SET 문을 사용한 데이터 추가
INSERT INTO users SET user_name='john', email='john@example.com', age=30;

SELECT * FROM users;