-- 데이터 제거(DELETE FROM)

SELECT * FROM users;

-- 특정 테이블에서 모든 행 삭제
DELETE FROM users;

-- 특정 조건을 만족하는 행 삭제
DELETE FROM users WHERE age >= 60;

-- LIMIT을 사용한 삭제
DELETE FROM orders WHERE user_name = 'young' LIMIT 2;

-- JOIN을 사용한 삭제
DELETE e FROM employees AS e
JOIN departments AS d ON e.department_id = d.id
WHERE d.name = 'Marketing';

-- USING을 사용한 삭제
DELETE FROM employees
USING employees, departments
WHERE employees.department_id = departments.id AND department.name = 'HR';